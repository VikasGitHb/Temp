package merck.com.merckbranding;

import android.content.Context;
import android.util.Log;

import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;


public class MerckBranding {

    Context context;

    public MerckBranding(Context context) {
        this.context = context;
    }

    public String getEULA(Branding branding) {
        InputStream ins;
        switch(branding) {
            case WITHIN_US_CANADA:
                ins = context.getResources().openRawResource(R.raw.uscanada);
                break;
            case OUTSIDE_US_CANADA:
                ins = context.getResources().openRawResource(R.raw.exuscanada);
                break;
            default:
                Log.d("MerckBranding", "getEula() called with incorrect parameter.");
                return null;
        }

        try {
            // the eula files have been converted to .txt for compatibility
            // possible to use .docx files for future iterations of this library if elements in .docs files are required
            StringWriter writer = new StringWriter();
            IOUtils.copy(ins, writer, "UTF-8");
            String license = writer.toString();
            return license;
        } catch (IOException io) {
            Log.d("MerckBranding", "io Exception : " + io.getLocalizedMessage());
            return null;
        }

    }

    public String getName(Branding branding) {
        // can directly call getString and access the string for US
        // purpose of this method is to prevent confusion
        switch(branding) {
            case WITHIN_US_CANADA:
                return context.getString(R.string.uscanada);
            case OUTSIDE_US_CANADA:
                return context.getString(R.string.exuscanada);
            default:
                Log.d("MerckBranding", "getName() called with incorrect parameter.");
                return null;
        }
    }

    public int getLogoID(Branding branding) {
        // can directly call using R.drawable.uscanada/exuscanada
        // purpose of this method is to prevent confusion
        switch(branding) {
            case WITHIN_US_CANADA:
                return R.drawable.mercklogo;
            case OUTSIDE_US_CANADA:
                return R.drawable.msdlogo;
            default:
                Log.d("MerckBranding", "getLogoID() called with incorrect parameter.");
                return 0;
        }
    }

    public String getCopyright(Branding branding) {
        switch(branding) {
            case WITHIN_US_CANADA:
                return context.getString(R.string.uscopyright);
            case OUTSIDE_US_CANADA:
                return context.getString(R.string.exuscopyright);
            default:
                Log.d("MerckBranding", "getLogoID() called with incorrect parameter.");
                return null;
        }
    }

    public String getAboutCompany(Branding branding) {
        switch(branding) {
            case WITHIN_US_CANADA:
                return context.getString(R.string.usaboutus);
            case OUTSIDE_US_CANADA:
                return context.getString(R.string.exusaboutus);
            default:
                Log.d("MerckBranding", "getAboutCompany() called with incorrect parameter.");
                return null;
        }
    }

}
