package merck.com.merckbranding;

public enum Branding {
    WITHIN_US_CANADA,
    OUTSIDE_US_CANADA
}
