package merck.com.merckcomponents;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.preference.PreferenceManager;

public class Agreements {

    private String PREFIX = "Agreements_";//just in case
    private Activity mActivity;
    private SharedPreferences sharedPreferences;
    private String AgreementName;
    private String AgreementText;
    private boolean Required;
    private VariableChanger onVariableChanged;
    private int icon;

    public Agreements(Activity context, String agreementName, String agreementText) {
        initialize(context, agreementName, agreementText, 0, false);
    }

    public Agreements(Activity context, String agreementName, String agreementText, boolean closeOnReject) {
        initialize(context, agreementName, agreementText, 0, closeOnReject);
    }

    public Agreements(Activity context, String agreementName, String agreementText, int iconID, boolean closeOnReject) {
        initialize(context, agreementName, agreementText, iconID, closeOnReject);
    }

    private void initialize(Activity context, String agreementName, String agreementText, int iconID, boolean closeOnReject) {
        //calling context
        this.mActivity = context;
        //agreement key
        this.PREFIX = agreementName + "_".replace(" ", "").trim();
        //access to shared preferences
        this.sharedPreferences = PreferenceManager.getDefaultSharedPreferences(mActivity);
        //close if not agreed
        this.Required = closeOnReject;
        //agreement display name
        this.AgreementName = AppName() + " " + agreementName;
        //agreement displayed text
        this.AgreementText = agreementText;
        //agreement display icon
        this.icon = iconID;
    }


    private PackageInfo getPackageInfo() {
        PackageInfo pi = null;
        try {
            pi = mActivity.getPackageManager().getPackageInfo(mActivity.getPackageName(), PackageManager.GET_ACTIVITIES);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return pi;
    }

    private String AppName() {
        ApplicationInfo applicationInfo = mActivity.getApplicationInfo();
        int stringId = applicationInfo.labelRes;
        return stringId == 0 ? applicationInfo.nonLocalizedLabel.toString() : mActivity.getString(stringId);
    }

    public String VersionName() {
        return getPackageInfo().versionName;
    }

    public int VersionCode() {
        return getPackageInfo().versionCode;
    }

    private String AgreementKey() {
        // the agreementKey changes every time you increment the version number in the AndroidManifest.xml
        // makes the agreement show every time there is an update
        return PREFIX + VersionCode();

    }

    public boolean Agreed() {
        final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(mActivity);
        return prefs.getBoolean(AgreementKey(), false);
    }

    public void resetAgreed() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(AgreementKey(), false);
        editor.commit();
        sendAnalytics();
    }

    public void setOnVariableChanged(VariableChanger onVariableChanged) {
        this.onVariableChanged = onVariableChanged;
    }

    public void setIcon(int iconID) {
        this.icon = iconID;
    }

    public void setMessage(String message) {
        this.AgreementText = message;
    }

    public void show() {

        if (!Agreed()) {
            final String title = this.AgreementName + " v" + VersionName();

            AlertDialog.Builder builder = new AlertDialog.Builder(mActivity)
                    .setTitle(title)
                    .setMessage(AgreementText)
                    .setPositiveButton(android.R.string.ok, new Dialog.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            // Mark this version as read.
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putBoolean(AgreementKey(), true);
                            editor.commit();
                            dialogInterface.dismiss();
                            if (null != onVariableChanged) {
                                onVariableChanged.onVariableChanged();
                            }
                            sendAnalytics();

                        }
                    })
                    .setNegativeButton(android.R.string.cancel, new Dialog.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            resetAgreed();
                            if (Required) {
                                //Show warning that the user has to agree
                                dialog.dismiss();
                                //very very clumsy
                                String dismissedWarning = mActivity.getString(R.string.requiredtext).replace(mActivity.getString(R.string.placeholder), title);
                                AlertDialog.Builder nestedBuilder = new AlertDialog.Builder(mActivity)
                                        .setTitle(title).setMessage(dismissedWarning).setOnDismissListener(new DialogInterface.OnDismissListener() {
                                            @Override
                                            public void onDismiss(DialogInterface dialog) {
                                                // Close the activity as they have declined a required agreement
                                                mActivity.finish();

                                            }
                                        });
                                nestedBuilder.show();
                            }
                        }

                    });

            if (this.icon != 0) builder.setIcon(icon);


            final AlertDialog alertDialog = builder.create();


            //BUTTON COLOURS
//            alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
//                                         @Override
//                                         public void onShow(DialogInterface dialogInterface) {
//                                             alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(MerckColors.GREEN.getARGB());
//                                             alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(MerckColors.ORANGE.getARGB());
//                                         }
//                                     });

            alertDialog.show();
        }
    }

    private void sendAnalytics() {
        AnalyticsHelper.Instance(mActivity).sendEvent(AppName(), AgreementName, String.valueOf(this.Agreed()));
    }

    public interface VariableChanger {
        void onVariableChanged();
    }


}
