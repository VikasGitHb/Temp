package merck.com.merckcomponents;

import android.content.pm.ApplicationInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class MerckActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AnalyticsHelper.Instance(this).sendEvent(AppName(), "SESSION", "CREATED");
    }

    @Override
    protected void onPause() {
        AnalyticsHelper.Instance(this).sendEvent(AppName(), "SESSION", "PAUSED");
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        AnalyticsHelper.Instance(this).sendEvent(AppName(), "SESSION", "DESTROYED");
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (getSupportFragmentManager().getBackStackEntryCount() == 0)
            AnalyticsHelper.Instance(this).sendEvent(AppName(), "SESSION", "CLOSINGONBACKPRESSED");
        super.onBackPressed();
    }

    @Override
    public void onLowMemory() {

        try {
            AnalyticsHelper.Instance(this).sendEvent(AppName(), "SESSION", "LOWMEMORY");
        } catch (Exception ex) {
        }

        super.onLowMemory();
    }

    private String AppName() {
        ApplicationInfo applicationInfo = this.getApplicationInfo();
        int stringId = applicationInfo.labelRes;
        return stringId == 0 ? applicationInfo.nonLocalizedLabel.toString() : this.getString(stringId);
    }
}
