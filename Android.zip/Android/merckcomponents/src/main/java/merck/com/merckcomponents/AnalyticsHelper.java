package merck.com.merckcomponents;


import android.content.Context;

import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;


public class AnalyticsHelper {
    static AnalyticsHelper instance = null;
    private static GoogleAnalytics sAnalytics;
    private static Tracker sTracker;
    Context context;

    AnalyticsHelper(Context context) {
        this.context = context;
        sAnalytics = GoogleAnalytics.getInstance(context);
    }

    public static AnalyticsHelper Instance(Context context) {
        if (null == instance) instance = new AnalyticsHelper(context);
        return instance;
    }

    synchronized public Tracker getDefaultTracker() {
        if (sTracker == null) {
            sTracker = sAnalytics.newTracker(R.xml.global_tracker);
        }

        return sTracker;
    }

    void sendEvent(String Category, String Action) {
        getDefaultTracker().send(new HitBuilders.EventBuilder().setCategory(Category).setAction(Action).build());
    }

    void sendEvent(String Category, String Action, String Label) {
        getDefaultTracker().send(new HitBuilders.EventBuilder().setCategory(Category).setAction(Action).setLabel(Label).build());
    }

    void sendEvent(String Category, String Action, String Label, Long Value) {
        getDefaultTracker().send(new HitBuilders.EventBuilder().setCategory(Category).setAction(Action).setLabel(Label).setValue(Value).build());
    }

}
