package merck.com.merckcomponents;

import android.content.Context;
import android.util.DisplayMetrics;

public class ScreenSize {
    static Context context;

    static ScreenSize instance = null;

    public static ScreenSize Instance(Context context) {
        if(null==instance) instance = new ScreenSize(context);
        return instance;
    }

    ScreenSize(Context context) {
        this.context = context;
        if(null != context) {
            DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
            Width = displayMetrics.widthPixels;
            Height = displayMetrics.heightPixels;
        }
    }

    public int Width;
    public int Height;

}
