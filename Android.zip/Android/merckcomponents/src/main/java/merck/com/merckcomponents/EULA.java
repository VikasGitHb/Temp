package merck.com.merckcomponents;

import android.app.Activity;

import merck.com.merckbranding.Branding;
import merck.com.merckbranding.MerckBranding;

//Wrapper for Agreements EULA
public class EULA {

    private Activity mActivity;
    private MerckBranding merckBranding;
    private Branding branding;
    private String AgreementName = "EULA";

    private Agreements agreements;

    public EULA(Activity context, Branding branding) {
        mActivity = context;
        this.branding = branding;
        merckBranding = new MerckBranding(mActivity);

        String message = merckBranding.getEULA(branding);

        agreements = new Agreements(mActivity, AgreementName, message, merckBranding.getLogoID(branding), true);
    }

    public void setOnVariableChanged(Agreements.VariableChanger onVariableChanged) {
        agreements.setOnVariableChanged(onVariableChanged);
    }

    public String VersionName() {
        return agreements.VersionName();
    }

    public void show() {
        agreements.show();
    }

    public boolean Agreed() {
        return agreements.Agreed();
    }

    public void resetAgreed() {
        agreements.resetAgreed();
    }


}
