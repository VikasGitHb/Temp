package merck.com.merckcolor;

import android.graphics.Color;
import android.util.Log;

//Official company colours from branding.merck.com and digital guidelines colours
//TODO Make More Maintainable
public enum MerckColors {
    TEAL(0, 135, 124),
    LIGHTTEAL(110, 206, 178),
    WARMGRAY(191, 184, 175),
    PURPLE(102, 32, 58),
    WHITE(255, 255, 255),
    BLACK(0, 0, 0),
    DARKGRAY(55, 66, 74),
    YELLOW(251, 225, 34),
    GREEN(154, 201, 46),
    GREEN500(0, 191, 165),
    GREEN900(0, 169, 138),
    GREEN200(128, 223, 210),
    CYAN500(0, 188, 212),
    CYAN900(0, 151, 185),
    CYAN200(128, 222, 234),
    INDIGO500(1, 87, 155),
    INDIGO900(0, 44, 109),
    INDIGO200(128, 171, 205),
    PURPLE500(103, 58, 183),
    PURPLE900(57, 24, 144),
    PURPLE200(131, 157, 219),
    ORANGE(246, 141, 46),
    GREEN700ACCENT(71, 255, 207),
    GREEN200ACCENT(147, 255, 227),
    CYAN700ACCENT(99, 221, 255),
    CYAN200ACCENT(175, 238, 255),
    INDIGO700ACCENT(29, 99, 255),
    INDIGO200ACCENT(105, 152, 255),
    PURPLE700ACCENT(115, 71, 255),
    PURPLE200ACCENT(173, 148, 255),
    YELLOW100ALERT(255, 249, 196),
    YELLOW500ALERT(255, 235, 52),
    YELLOW900ALERT(255, 221, 24),
    ORANGE100ALERT(255, 224, 179),
    ORANGE500ALERT(255, 152, 0),
    ORANGE900ALERT(255, 106, 0),
    RED100ALERT(255, 199, 195),
    RED500ALERT(244, 67, 54),
    RED900ALERT(236, 30, 22),
    GREEN100ALERT(220, 237, 201),
    GREEN500ALERT(187, 195, 74),
    GREEN900ALERT(91, 161, 34),
    BLUE100ALERT(179, 229, 252),
    BLUE500ALERT(3, 73, 244),
    BLUE900ALERT(1, 126, 236),
    GREYSCALE100(242, 245, 247),
    GREYSCALE200(236, 239, 241),
    GREYSCALE300(207, 216, 220),
    GREYSCALE400(144, 164, 174),
    GREYSCALE500(96, 125, 139),
    GREYSCALE600(51, 77, 91),
    GREYSCALE700(20, 37, 47);


    public final int red;
    public final int green;
    public final int blue;
    private final String rgbString;
    private final String hexString;

    MerckColors(final int r, final int g, final int b) {
        this.red = r;
        this.green = g;
        this.blue = b;
        this.rgbString = r + ", " + g + ", " + b;
        this.hexString = "#" + hex(r) + hex(g) + hex(b);
    }

    //Returns a string with hex/RGB format
    public String ColorString(ColorFormat colorFormat) {
        //returns either the rgb or hex String when input is 'rgb' or 'hex' respectively
        switch (colorFormat) {
            case HEX:
                return hexString;
            case RGB:
                return rgbString;
            default:
                Log.d("MerckColors", "Invalid ColorFormat Passed To String");
                return rgbString;
        }
    }

    //Returns the Color for the given name
    public Color getColor() {
        return new Color().valueOf(red, green, blue);
    }

    //Returns the color as an ARGB int
    public int getARGB() {
        return 0xFF000000 | ((red << 16) & 0x00ff0000) | ((green << 8) & 0x0000ff00) | blue;
    }

    //included this method to place leading zeros in front of each red green and blue number when it is
    //converted from decimal to a hexstring and also uppercases the relevant hex numbers
    private String hex(int i) {
        return Integer.toHexString(0x100 | i).substring(1).toUpperCase();
    }
}

