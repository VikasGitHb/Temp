package merck.com.merckcolor;

public enum ColorFormat {
    RGB,
    HEX
}
