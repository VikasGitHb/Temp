package merck.com.merckcolor;

import android.graphics.Color;

public class Colors {
    private static final Colors instance = new Colors();

    private Colors() {
    }

    public static Colors getInstance() {
        return instance;
    }

    public Color BrandedColor(MerckColors name) {
        return name.getColor();
    }

}
