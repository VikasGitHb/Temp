package com.merck.ComponentTest;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import merck.com.merckbranding.Branding;
import merck.com.merckbranding.MerckBranding;
import merck.com.merckcolor.MerckColors;
import merck.com.merckcomponents.Agreements;
import merck.com.merckcomponents.EULA;
import merck.com.merckcomponents.MerckActivity;
import merck.com.merckviews.MerckEditText;
import merck.com.merckviews.MerckTextView;

public class MainActivity extends MerckActivity {

    EULA eula;

    LinearLayout rootLayout;
    MerckTextView statusTextView;
    MerckTextView customStatusTextView;
    MerckTextView versionTextView;
    MerckTextView colorTextView;
    MerckTextView copyrightTextView;
    MerckTextView merckEditTextOutput;
    MerckEditText merckEditText;
    Button changeColorButton;
    Button resetEULA;
    Button resetCustom;
    Button switchBrand;

    MerckBranding merckBranding;
    Branding branding;

    Agreements customAgreement;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        branding = Branding.OUTSIDE_US_CANADA;
        setContentView(R.layout.activity_main);
        rootLayout = findViewById(R.id.rootLayout);
        statusTextView = (MerckTextView) findViewById(R.id.EulaStatus);

        versionTextView = (MerckTextView) findViewById(R.id.Version);
        resetEULA = (Button) findViewById(R.id.eulabutton);
        customStatusTextView = findViewById(R.id.customStatus);
        resetCustom = findViewById(R.id.custombutton);
        merckBranding = new MerckBranding(this);
        copyrightTextView = (MerckTextView) findViewById(R.id.copyright);
        copyrightTextView.setText(merckBranding.getCopyright(branding));
        copyrightTextView.setTextColor(MerckColors.BLUE900ALERT.getARGB());
        switchBrand = findViewById(R.id.brandbutton);
        switchBrand.setText("Show (C) for " + merckBranding.getName(Branding.WITHIN_US_CANADA));
        switchBrand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (branding) {
                    case WITHIN_US_CANADA:
                        branding = Branding.OUTSIDE_US_CANADA;
                        switchBrand.setText("Show (C) for " + merckBranding.getName(Branding.WITHIN_US_CANADA));
                        break;
                    case OUTSIDE_US_CANADA:
                        branding = Branding.WITHIN_US_CANADA;
                        switchBrand.setText("Show (C) for " + merckBranding.getName(Branding.OUTSIDE_US_CANADA));
                        break;
                }
                copyrightTextView.setText(merckBranding.getCopyright(branding));
            }
        });
        merckEditTextOutput = findViewById(R.id.merckedittextoutput);
        merckEditText = findViewById(R.id.merckedittext);
        //trying to set text size to ludicrously low, should be overridden
        merckEditText.setTextSize(1);
        merckEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                merckEditTextOutput.setText(s);
            }

            @Override
            public void afterTextChanged(Editable s) {
                merckEditTextOutput.setText(merckEditText.getEscapedText());
            }
        });
        PopulateTestCustom();

        PopulateTestEula();
        AddColorTest();
    }

    void PopulateTestEula() {
        Log.d("MerckEULA", "Trying to set branding and show EULA");
        eula = new EULA(this, Branding.OUTSIDE_US_CANADA);
        statusTextView.setText("EULA Agreed == " + String.valueOf(eula.Agreed()));
        resetEULA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eula.resetAgreed();
                statusTextView.setText("EULA Agreed == " + String.valueOf(eula.Agreed()));
            }
        });
        resetEULA.setText("Reset EULA Flag");
        versionTextView.setText(eula.VersionName());
        eula.setOnVariableChanged(new Agreements.VariableChanger() {
            @Override
            public void onVariableChanged() {
                statusTextView.setText("EULA Agreed == " + String.valueOf(eula.Agreed()));
                Log.d("MerckEULA", "Agreed == " + String.valueOf(eula.Agreed()));
            }
        });
        eula.show();
        if (eula.Agreed()) //avoid multiple dialogs
        {
            displayCustomAgreementStub();
        }

        Log.d("MerckEULA", "App version according to EULA == " + String.valueOf(eula.VersionName()));
        Log.d("MerckEULA", "Agreed == " + String.valueOf(eula.Agreed()));
    }

    void PopulateTestCustom() {
        customAgreement = new Agreements(this, "CUSTOM", "THIS IS A TEST FOR A CUSTOM AGREEMENT WITH A PERSISTENT VARIABLE WHICH DOESN'T CLOSE THE APP ON REJECT, AND HAS NO CALLBACK", false);
        customStatusTextView.setText("CUSTOM Agreed == " + String.valueOf(customAgreement.Agreed()));
        resetCustom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != customAgreement) {
                    customAgreement.resetAgreed();
                    customStatusTextView.setText("CUSTOM Agreed == " + String.valueOf(customAgreement.Agreed()));
                }
            }
        });

    }

    void AddColorTest() {
        colorTextView = new MerckTextView(this);
        colorTextView.setText("COLOR OUTPUT");
        colorTextView.setBackgroundColor(MerckColors.ORANGE.getARGB());
        colorTextView.setTextColor(MerckColors.TEAL.getARGB());
        rootLayout.addView(colorTextView);
        changeColorButton = new Button(this);
        changeColorButton.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        changeColorButton.setText("CLICK ME TO CHANGE COLOR");
        changeColorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int destColor = MerckColors.ORANGE.getARGB();
                int destBGColor = MerckColors.TEAL.getARGB();
                if (colorTextView.getCurrentTextColor() == MerckColors.ORANGE.getARGB()) {
                    destColor = MerckColors.TEAL.getARGB();
                    destBGColor = MerckColors.ORANGE.getARGB();
                }
                colorTextView.setTextColor(destColor);
                colorTextView.setBackgroundColor(destBGColor);
            }
        });

        rootLayout.addView(changeColorButton);

    }

    void displayCustomAgreementStub() {
        Log.d("MERCKCUSTOMAGREEMENT", "AGREED() == " + String.valueOf(customAgreement.Agreed()));
        customAgreement.show();
        Log.d("MERCKCUSTOMAGREEMENT", "AGREED() == " + String.valueOf(customAgreement.Agreed()));
    }


}
