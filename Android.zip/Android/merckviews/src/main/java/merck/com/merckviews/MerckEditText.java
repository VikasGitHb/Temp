package merck.com.merckviews;

import android.content.Context;
import android.database.DatabaseUtils;
import android.support.v7.widget.AppCompatEditText;
import android.text.InputType;
import android.util.AttributeSet;
import android.util.Patterns;
import android.view.inputmethod.EditorInfo;

import org.apache.commons.text.StringEscapeUtils;

//TODO: check set inputtype and validation based on inputtype
public class MerckEditText extends AppCompatEditText {
    //TODO check min/max limits for UI/UX expectations
    //values populated from Digital Guidelines recommendations
    private int min_padding_limit = 12;
    private int max_padding_limit = 48;
    private float min_font_size = 11;

    public MerckEditText(Context context) {
        super(context);
        initialize();
    }

    public MerckEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        initialize();
    }


    public MerckEditText(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initialize();
    }

    private float checkFontSize(float size) {
        return Math.max(min_font_size, size);
    }

    private void initialize() {
        if (this.getInputType() == 131073) {
            this.setInputType(InputType.TYPE_CLASS_TEXT);
        }
        if (0 == this.getImeActionId() || null == this.getImeActionLabel()) {
            this.setImeOptions(EditorInfo.IME_ACTION_DONE);
        }
        setPadding(this.getLeft(), this.getTop(), this.getRight(), this.getBottom());
        setTextSize(this.getTextSize());
    }

    private boolean paddingAboveMin(int value) {
        return value > min_padding_limit;
    }

    private boolean paddingBelowMax(int value) {
        return value < max_padding_limit;
    }

    private int checkPadding(int value) {
        return Math.max(min_padding_limit, Math.min(max_padding_limit, value));
    }

    public String getEscapedText() {
        //Still need to used parameterized SQL/SQLite queries
        //trim text and replace single quotes.
        //because StringEscapeUtils.escapeJava doesn't escape apostrophes and StringEscapeUtils.escapeSQL isn't available
        //and because DatabaseUtils leaves double quotes untouched...
        String content = this.getText().toString().trim();
        String escapedContent = DatabaseUtils.sqlEscapeString(StringEscapeUtils.escapeJava(content));
        return escapedContent;
    }


    @Override
    public void setPadding(int left, int top, int right, int bottom) {
        left = checkPadding(left);
        top = checkPadding(top);
        right = checkPadding(right);
        bottom = checkPadding(bottom);
        super.setPadding(left, top, right, bottom);
    }


    public boolean isValidEmail() {
        return Patterns.EMAIL_ADDRESS.matcher(this.getText()).matches();
    }

    public boolean isValidURI() {
        return Patterns.WEB_URL.matcher(this.getText()).matches();
    }


    @Override
    public void setTextSize(float size) {
        super.setTextSize(checkFontSize(size));
    }

    @Override
    public void setTextSize(int unit, float size) {
        size = checkFontSize(size);
        super.setTextSize(unit, size);
    }

    //TODO onfocuschangelistener - if lost dismiss keyboard
}


