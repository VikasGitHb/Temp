package merck.com.merckviews;

import android.content.Context;
import android.support.v7.widget.AppCompatTextView;
import android.util.AttributeSet;

public class MerckTextView extends AppCompatTextView {
    //TODO check min/max limits for UI/UX expectations
    //values to be populated from Digital Guidelines recommendations
    private int min_padding_limit = 12;
    private int max_padding_limit = 48;
    private float min_font_size = 11;

    public MerckTextView(Context context) {
        super(context);
        setPadding(this.getLeft(), this.getTop(), this.getRight(), this.getBottom());
    }

    public MerckTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setPadding(this.getLeft(), this.getTop(), this.getRight(), this.getBottom());
    }

    public MerckTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setPadding(this.getLeft(), this.getTop(), this.getRight(), this.getBottom());
    }

    private boolean fontsizeAboveMin(float size) {
        return size > min_font_size;
    }

    private float checkFontSize(float size) {
        return Math.max(size, min_font_size);
    }


    @Override
    public void setTextSize(float size) {
        size = checkFontSize(size);
        super.setTextSize(size);
    }

    @Override
    public void setTextSize(int unit, float size) {
        size = checkFontSize(size);
        super.setTextSize(unit, size);
    }

    private boolean paddingAboveMin(int value) {
        return value > min_padding_limit;
    }

    private boolean paddingBelowMax(int value) {
        return value < max_padding_limit;
    }

    private int checkPadding(int value) {
        return Math.max(min_padding_limit, Math.min(max_padding_limit, value));
    }

    @Override
    public void setPadding(int left, int top, int right, int bottom) {
        left = checkPadding(left);
        top = checkPadding(top);
        right = checkPadding(right);
        bottom = checkPadding(bottom);
        super.setPadding(left, top, right, bottom);
    }
}
